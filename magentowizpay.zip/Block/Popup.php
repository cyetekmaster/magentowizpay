<?php
namespace Wizpay\Wizpay\Block;
class Popup extends \Magento\Framework\View\Element\Template
{
    public function getContent() : string
    {
        return 'test popup';
    }
}